package com.app.login.facade;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.app.login.dto.UserRegistroDTO;
import com.app.login.model.User;

public interface IUser  extends UserDetailsService {
    
	public User save(UserRegistroDTO registroDTO); 
	
}
