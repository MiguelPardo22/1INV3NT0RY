package com.app.login.dto;



public class UserRegistroDTO {

	private long id_usu;
	private String nombre;
	private String apellido;
	private String email;
	private String password;
	public long getId_usu() {
		return id_usu;
	}
	public void setId_usu(long id_usu) {
		this.id_usu = id_usu;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public UserRegistroDTO(long id_usu, String nombre, String apellido, String email, String password) {
		super();
		this.id_usu = id_usu;
		this.nombre = nombre;
		this.apellido = apellido;
		this.email = email;
		this.password = password;
	}
	public UserRegistroDTO(String nombre, String apellido, String email, String password) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.email = email;
		this.password = password;
	}
	public UserRegistroDTO() {
		super();
	}
}
