package com.app.login.facadeimp;

import java.util.Arrays;
import java.util.Collection;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.app.login.dto.UserRegistroDTO;
import com.app.login.facade.IUser;
import com.app.login.model.Rol;
import com.app.login.model.User;
import com.app.login.repository.UserRepository;

@Service
public class UserDao implements IUser{

	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
     private UserRepository	userrepo;
     
	public UserDao(UserRepository userrepo) {
		super();
		this.userrepo = userrepo;
	}

	@Override
	public User save(UserRegistroDTO registroDTO) {
	      User us = new User(registroDTO.getNombre(), registroDTO.getApellido(),
	    		  registroDTO.getEmail(),
	    		 passwordEncoder.encode(registroDTO.getPassword()),
	    		  Arrays.asList(new Rol("Rol_User")));
		return userrepo.save(us);
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		 User us = userrepo.findByEmail(username);
		 
		 if(us == null) {
			 
			 throw new UsernameNotFoundException("Usuario o Contraseña invalidos");
			 
		 }
		 
		return new org.springframework.security.core.userdetails.User(us.getEmail(),us.getPassword(), mapearAutoridadesRoles(us.getRoles()));
	}

	private Collection<? extends GrantedAuthority> mapearAutoridadesRoles(Collection<Rol> roles){
		
		return roles.stream().map(role -> new SimpleGrantedAuthority(role.getNom())).collect(Collectors.toList());
		
	}
	
}
