package com.app.web.facadeimp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.web.Repository.RoleRepository;
import com.app.web.Repository.UserRepository;
import com.app.web.facade.IUser;
import com.app.web.model.Role;
import com.app.web.model.User;

@Service
public class UserDao implements IUser{

	@Autowired
	UserRepository userrepo;
	
	@Autowired
	RoleRepository rolerepo;
	
	@Override
	public List<User> EncontrarUser() {
		return userrepo.findAll();
	}

	@Override
	public Optional<User> getOne(Integer id_usu) {
		return userrepo.findById(id_usu);
	}

	@Override
	public User findById(Integer id_usu) {
		return userrepo.getReferenceById(id_usu);
	}

	@Override
	public void create(User user) {
		this.userrepo.save(user);
		
	}

	@Override
	public void update(User user) {
		this.userrepo.save(user);
	}

	@Override
	public void delete(User user) {
		User us = this.userrepo.getById(user.getId_usu());
		this.userrepo.save(us);
	}

}
