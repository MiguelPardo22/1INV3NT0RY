package com.app.web.model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.TemporalType;
import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "Compra")
public class Purchase implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_com;
	
	@Column(name="Numero_Factura",length=40)
	private String Num_fac;
	
	@Column(name="Total_Compra",length=40)
	private String Tot_com;
	
	@Temporal(TemporalType.DATE)
    private Date Fecha;
	
	@ManyToOne
	@JoinColumn(name="id_Supplier_fk", referencedColumnName = "id_Proveedor")
	private Supplier id_Supplier_fk; 
	
	@OneToMany(mappedBy = "id_Purchase_fk")
	private List<DetailPurchase>ListDetailPurchase;

	public int getId_com() {
		return id_com;
	}

	public void setId_com(int id_com) {
		this.id_com = id_com;
	}

	public String getNum_fac() {
		return Num_fac;
	}

	public void setNum_fac(String num_fac) {
		Num_fac = num_fac;
	}

	public String getTot_com() {
		return Tot_com;
	}

	public void setTot_com(String tot_com) {
		Tot_com = tot_com;
	}

	public Date getFecha() {
		return Fecha;
	}

	public void setFecha(Date fecha) {
		Fecha = fecha;
	}

	public Supplier getId_Supplier_fk() {
		return id_Supplier_fk;
	}

	public void setId_Supplier_fk(Supplier id_Supplier_fk) {
		this.id_Supplier_fk = id_Supplier_fk;
	}

}
