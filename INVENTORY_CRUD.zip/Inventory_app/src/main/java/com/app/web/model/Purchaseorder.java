package com.app.web.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "Orden_Compra")
public class Purchaseorder implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_orden_compra;
	
	@Temporal(TemporalType.DATE)
    private Date Fecha;
	
	@ManyToOne
	@JoinColumn(name="id_Supplier_fk", referencedColumnName = "id_Proveedor")
	private Supplier id_Supplier_fk; 
	
	@OneToMany(mappedBy = "id_PurchaseOrder_fk")
	private List<Detalle_OrderCompra>ListDetalleOrdenCompra;

	public int getId_orden_compra() {
		return id_orden_compra;
	}

	public void setId_orden_compra(int id_orden_compra) {
		this.id_orden_compra = id_orden_compra;
	}

	public Date getFecha() {
		return Fecha;
	}

	public void setFecha(Date fecha) {
		Fecha = fecha;
	}

	public Supplier getId_Supplier_fk() {
		return id_Supplier_fk;
	}

	public void setId_Supplier_fk(Supplier id_Supplier_fk) {
		this.id_Supplier_fk = id_Supplier_fk;
	}
	
	
}
