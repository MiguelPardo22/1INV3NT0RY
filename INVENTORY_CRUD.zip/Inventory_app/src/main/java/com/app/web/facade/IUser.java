package com.app.web.facade;

import java.util.List;
import java.util.Optional;

import com.app.web.model.Role;
import com.app.web.model.User;

public interface IUser {
	
	public List<User>EncontrarUser();
	public Optional<User>getOne(Integer id_usu);
	public User findById(Integer id_usu);
	public void create(User user);
	public void update(User user);
	public void delete(User user);
	
 }
