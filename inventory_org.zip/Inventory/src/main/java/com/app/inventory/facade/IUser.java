package com.app.inventory.facade;

import org.springframework.security.core.userdetails.UserDetailsService;
import com.app.inventory.dto.UserRegistroDTO;
import com.app.inventory.model.User;


public interface IUser  extends UserDetailsService {
    
	public User save(UserRegistroDTO registroDTO); 
	
}
