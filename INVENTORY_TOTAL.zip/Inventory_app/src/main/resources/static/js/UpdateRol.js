/**
 * 
 */
 
 $('document').ready(function() {
	 
	 $('.table #update').on('click', function(event){
		 
		 event.preventDefault();
		  
		var href= $(this).attr('href');
		 
		 $.get(href, function(role, status){
			 
			 $('#idRolEdit').val(role.id_Rol);
			 $('#nomEdit').val(role.nom);
			 $('#estEdit').val(role.est);
			 //$('#nomEdit').val(role.nom);
			 
		 });
		 
		 $('#editModal').modal();
		 
	 });
	  });
	$('document').ready(function() { 
	 $('.table #updateButton').on('click', function(event){
		 
		 event.preventDefault();
		  
		 var href = $(this).attr('href');
		 	
		 $('#updateEstModal #delRef').attr('href', href);
		  $('#updateEstModal').modal();
	 });
	    });