package com.app.web.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Detalle_OrdenCompra")
public class Detalle_OrderCompra implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_Detalle_Compra;
	
	@Column(name="Cantidad",length=40)
	private int Can;
	
	@Column(name="SubTotal",length=40)
	private int SubTot;
	
	@Column(name="Total",length=40)
	private int Total;
	
	@ManyToOne
	@JoinColumn(name="id_prod_fk", referencedColumnName = "id_prod")
	private Product id_prod_fk; 
	
	@ManyToOne
	@JoinColumn(name="id_PurchaseOrder_fk", referencedColumnName = "id_orden_compra")
	private Purchaseorder id_PurchaseOrder_fk; 
	
}
