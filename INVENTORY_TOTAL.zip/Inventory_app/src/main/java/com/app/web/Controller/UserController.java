package com.app.web.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.app.web.facadeimp.RoleDao;
import com.app.web.facadeimp.UserDao;
import com.app.web.model.Role;
import com.app.web.model.User;

@Controller
public class UserController {

	@Autowired
	UserDao userdao;
	
	@Autowired
	RoleDao roledao;
	
	@RequestMapping({"/UserWEB", "/"})
	public String ListUser(Model modelo){
		modelo.addAttribute("User", userdao.EncontrarUser());
		return "UserWEB";
	}
	
	@RequestMapping({"/getOneUser"})
	@ResponseBody
	public Optional<User> getOne(Integer id_usu){
		return userdao.getOne(id_usu);
	}
	
	@PostMapping({"/Usercrear"})
	public String create(User user, Model modelo){
		
		List<Role> lstrole = roledao.Encontrarrole();
		modelo.addAttribute("lstrole", lstrole); 
		
		userdao.create(user);
		return "redirect:/UserWEB";
	}
	
	@RequestMapping(value="/Userupdate", method = {RequestMethod.PUT, RequestMethod.GET})
	public String update(User user){
		userdao.update(user);
		return "redirect:/UserWEB";
	}
	
	@RequestMapping(value="/Userdelete", method = {RequestMethod.PUT, RequestMethod.GET})
	public String delete(Integer id_usu) {
		
		User us = userdao.findById(id_usu);
		us.setEst("Inactivo");
		
		this.userdao.delete(us);
		return "redirect:/UserWEB";
	}
	
}
