package com.nvetory.demo.model.facadeImp;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nvetory.demo.model.Role;
import com.nvetory.demo.model.Repository.RolRepository;
import com.nvetory.demo.model.facade.IRol;

@Service
public class RoleDao implements IRol {
	
	@Autowired
	private RolRepository rolerepo;

	@Override
	public List<Role> findALL() {
		return this.rolerepo.findAll();
	}
	
	@Override
	public Role findById(int id_Rol) {
		return this.rolerepo.getReferenceById(id_Rol);
	}

	@Override
	public void create(Role role) {
		this.rolerepo.save(role);
		
	}

	@Override
	public void Update(Role role) {
		this.rolerepo.save(role);
	}

	@Override
	public void Delete(Role role) {
		Role ro=this.rolerepo.getById(role.getId_Rol());
		this.rolerepo.delete(ro);
	}

	

}
