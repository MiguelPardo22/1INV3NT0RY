package com.nvetory.demo.model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "Producto")
public class Product  implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_prod;

	@Column(name="Referencia",length=40)
	private long Ref;
	
	@Column(name="Nombre",length=40)
	private String nom;
	
	@ManyToOne
	@JoinColumn(name="id_Estado_fk", referencedColumnName = "id_estado")
	private State id_Estado_fk;
	
	@OneToMany(mappedBy = "id_prod_fk")
	private List<Orderdetail>Listorderdetail;
	
	@OneToMany(mappedBy = "id_prod_fk")
	private List<InventoryDetail>ListInventoryDetail;
	
	@OneToMany(mappedBy = "id_prod_fk")
	private List<Detalle_OrderCompra>ListDetalleOrdenCompra;
	
	@OneToMany(mappedBy = "id_prod_fk")
	private List<DetailPurchase> ListDetailPurchase;

	public int getId_prod() {
		return id_prod;
	}

	public void setId_prod(int id_prod) {
		this.id_prod = id_prod;
	}

	public long getRef() {
		return Ref;
	}

	public void setRef(long ref) {
		Ref = ref;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public State getId_Estado_fk() {
		return id_Estado_fk;
	}

	public void setId_Estado_fk(State id_Estado_fk) {
		this.id_Estado_fk = id_Estado_fk;
	}
}
			