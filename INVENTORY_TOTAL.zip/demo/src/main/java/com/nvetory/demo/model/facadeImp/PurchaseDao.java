package com.nvetory.demo.model.facadeImp;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nvetory.demo.model.Purchase;
import com.nvetory.demo.model.Repository.PurchaseRepository;
import com.nvetory.demo.model.facade.IPurchase;

@Service
public class PurchaseDao implements IPurchase{

	@Autowired
	private PurchaseRepository purchaserepo;
	
	@Override
	public List<Purchase> findALL() {
		return this.purchaserepo.findAll();
	}

	@Override
	public Purchase findById(int id_com) {
		return this.purchaserepo.getReferenceById(id_com);
	}

	@Override
	public void create(Purchase purchase) {
		this.purchaserepo.save(purchase);
		
	}

	@Override
	public void Update(Purchase purchase) {
		this.purchaserepo.save(purchase);
		
	}

	@Override
	public void Delete(Purchase purchase) {
		Purchase pur=this.purchaserepo.getById(purchase.getId_com());
		this.purchaserepo.delete(pur);
		
	}

}