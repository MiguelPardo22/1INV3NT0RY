package com.nvetory.demo.model.facadeImp;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nvetory.demo.model.Inventory;
import com.nvetory.demo.model.Repository.InventoryRepository;
import com.nvetory.demo.model.facade.Iinventory;

@Service
public class InventoryDao implements Iinventory{

	@Autowired
	private InventoryRepository invrepo;
	
	@Override
	public List<Inventory> findALL() {
		return this.invrepo.findAll();
	}

	@Override
	public Inventory findById(int id_inventario) {
		return this.invrepo.getReferenceById(id_inventario);
	}

	@Override
	public void create(Inventory  inventory) {
		this.invrepo.save(inventory);
		
	}

	@Override
	public void Update(Inventory inventory) {
		this.invrepo.save(inventory);
		
	}

	@Override
	public void Delete(Inventory inventory) {
		Inventory  inv =this.invrepo.getById(inventory.getId_inventario());
		this.invrepo.delete(inv);
		
	}

}