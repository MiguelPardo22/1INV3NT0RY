package com.nvetory.demo.model.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.nvetory.demo.Utilities.Utility;
import com.nvetory.demo.model.Order;
import com.nvetory.demo.model.Sale;
import com.nvetory.demo.model.State;
import com.nvetory.demo.model.User;
import com.nvetory.demo.model.facadeImp.OrderDao;
import com.nvetory.demo.model.facadeImp.SaleDao;
@Controller
@RequestMapping(path = "/api/demo/Sale")
public class SaleController {

	@Autowired
	private SaleDao Saledao;
	@Autowired
	private OrderDao orderDao;
	
	
	@GetMapping("/all")
    public ResponseEntity<Map<String,Object>> allState(){
   	 List<Sale>ListSale=this.Saledao.findALL();
   	 Map<String,Object> respon=new HashMap<String,Object>();
   	 respon.put("data",ListSale);
   	  return new ResponseEntity<>(respon,HttpStatus.OK);
    }	
	
	@PostMapping("/create")
    public ResponseEntity<Map<String,Object>> createSale(
   		 @RequestBody Map<String,Object> request){
   	 Map<String,Object> respon=new HashMap();
   	 System.out.println("@@@@"+request.toString());
   	 
   	Sale sal= new Sale();
   	 sal.setTotal((int) request.get("Total"));
   	   
   	 Order or = this.orderDao.findById(Integer.parseInt(request.get("id_ped_fk").toString()));
	 sal.setId_ped_fk(or);
	 
   	 respon.put("Message", "Se guardo exitosamente");
   	 this.Saledao.create(sal);
   	 
   	 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
	
	@PutMapping("/update/{id_ven}")
    public ResponseEntity<Map<String,Object>> UpdateSale(
   		 @RequestBody Map<String,Object> request){
   	 Map<String,Object> respon=new HashMap();
   	 System.out.println("@@@@"+request.toString());
   	
 	Sale sal= new Sale();
   	 
 	 sal.setId_ven((int) request.get("id_ven"));
 	 sal.setTotal((int) request.get("Total"));
 	 
   	 Order or = this.orderDao.findById(Integer.parseInt(request.get("id_ped_fk").toString()));
	 sal.setId_ped_fk(or);
  	 
   	 respon.put("Message", "Se actualizo exitosamente");
   	 this.Saledao.Update(sal);
   	 
   	 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
	
	@GetMapping("/delete/{id_ven}")
    private ResponseEntity<Map<String, Object>> deleteSale(@PathVariable String id_ven) {
   	 Map<String,Object> respon=new HashMap<String,Object>();
   	 Sale sal = this.Saledao.findById(Integer.parseInt(id_ven));
   	 this.Saledao.Delete(sal);
		 respon.put("Mensaje", "Se ha borrado");
		 List<Sale> lista=this.Saledao.findALL();
		 respon.put("data", lista);
		 respon.put("Status", HttpStatus.OK);
		 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
	
}

