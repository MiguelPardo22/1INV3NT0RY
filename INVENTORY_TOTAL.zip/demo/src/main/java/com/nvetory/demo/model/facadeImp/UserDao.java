package com.nvetory.demo.model.facadeImp;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nvetory.demo.model.User;
import com.nvetory.demo.model.Repository.UserRepository;
import com.nvetory.demo.model.facade.IUser;

@Service
public class UserDao implements IUser{

	@Autowired
	private UserRepository userrepo;
	
	@Override
	public List<User> findALL() {
		return this.userrepo.findAll();
	}

	@Override
	public User findById(int id_usu) {
		return this.userrepo.getReferenceById(id_usu);
	}

	@Override
	public void create(User user) {
		this.userrepo.save(user);
		
	}

	@Override
	public void Update(User user) {
		this.userrepo.save(user);
		
	}

	@Override
	public void Delete(User user) {
		User us=this.userrepo.getById(user.getId_usu());
		this.userrepo.delete(us);
		
	}

}
