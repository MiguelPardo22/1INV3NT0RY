package com.nvetory.demo.model.facade;

import java.util.List;
import com.nvetory.demo.model.Purchase;

public interface IPurchase {

	public List<Purchase> findALL();
	public Purchase findById(int id_com);
	public void create (Purchase purchase);
	public void Update (Purchase purchase);
	public void Delete (Purchase purchase);
	
}
