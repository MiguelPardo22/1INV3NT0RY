package com.nvetory.demo.model.facade;

import java.util.List;
import com.nvetory.demo.model.Product;

public interface IProduct {

	public List<Product> findALL();
	public Product findById(int id_prod);
	public void create (Product product);
	public void Update (Product product);
	public void Delete (Product product);
	
}

