package com.nvetory.demo.model.controller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nvetory.demo.model.Permission;
import com.nvetory.demo.model.facadeImp.PermissionDao;

@Controller
@RequestMapping(path = "/api/demo/Permission")
public class PermissionController {



       @Autowired
	private PermissionDao permissiondao;
	
	
	@GetMapping("/all")
    public ResponseEntity<Map<String,Object>> allState(){
   	 List<Permission>ListPermission=this.permissiondao.findALL();
   	 Map<String,Object> respon=new HashMap<String,Object>();
   	 respon.put("data",ListPermission);
   	  return new ResponseEntity<>(respon,HttpStatus.OK);
    }	
	
	@PostMapping("/create")
    public ResponseEntity<Map<String,Object>> createPermission(
   		 @RequestBody Map<String,Object> request){
   	 Map<String,Object> respon=new HashMap();
   	 System.out.println("@@@@"+request.toString());
   	 
   	 Permission perm= new Permission();
   	 perm.setNomPer((String) request.get("NomPer"));

   	 respon.put("Message", "Se guardo exitosamente");
   	 this.permissiondao.create(perm);
   	 
   	 return new ResponseEntity<>(respon,HttpStatus.OK);
    }

	@PutMapping("/update/{id_permiso}")
    public ResponseEntity<Map<String,Object>> UpdatePermission(
   		 @RequestBody Map<String,Object> request){
   	 Map<String,Object> respon=new HashMap();
   	 System.out.println("@@@@"+request.toString());

     Permission perm= new Permission();
         perm.setId_Permiso((int) request.get("id_permiso"));
   	     perm.setNomPer((String) request.get("NomPer"));

   	 respon.put("Message", "Se guardo exitosamente");
   	 this.permissiondao.Update(perm);
   	 
   	 return new ResponseEntity<>(respon,HttpStatus.OK);
	 }
   	
 	@GetMapping("/delete/{id_permiso}")
    private ResponseEntity<Map<String, Object>> deletePermission(@PathVariable String id_permiso) {
   	 Map<String,Object> respon=new HashMap<String,Object>();
   	 Permission perm = this.permissiondao.findById(Integer.parseInt(id_permiso));
   	 this.permissiondao.Delete(perm);
		 respon.put("Mensaje", "Se ha borrado");
		 List<Permission> lista=this.permissiondao.findALL();
		 respon.put("data", lista);
		 respon.put("State", HttpStatus.OK);
		 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
	
	
}
