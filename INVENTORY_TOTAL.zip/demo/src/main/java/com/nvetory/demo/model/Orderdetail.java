package com.nvetory.demo.model;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "Detalle_Pedido")
public class Orderdetail implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_det_ped;
	
	@Column(name="Cantidad",length=40)
	private int cant;
	
	@ManyToOne
	@JoinColumn(name="id_ped_fk", referencedColumnName = "id_Ped")
	private Order id_ped_fk; 
	
	@ManyToOne
	@JoinColumn(name="id_prod_fk", referencedColumnName = "id_prod")
	private Product id_prod_fk; 
	
}
