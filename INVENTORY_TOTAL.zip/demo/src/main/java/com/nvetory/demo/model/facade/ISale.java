
package com.nvetory.demo.model.facade;

import java.util.List;
import com.nvetory.demo.model.Sale;

public interface ISale {

	public List<Sale> findALL();
	public Sale findById(int id_ven);
	public void create (Sale sale);
	public void Update (Sale sale);
	public void Delete (Sale sale);
	
}
