package com.nvetory.demo.model.facadeImp;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nvetory.demo.model.Order;
import com.nvetory.demo.model.Repository.OrderRepository;
import com.nvetory.demo.model.facade.IOrder;

@Service
public class OrderDao implements IOrder{

	@Autowired
	private OrderRepository ordrepo;
	
	@Override
	public List<Order> findALL() {
		return this.ordrepo.findAll();
	}

	@Override
	public Order findById(int id_Ped) {
		return this.ordrepo.getReferenceById(id_Ped);
	}

	@Override
	public void create(Order  order) {
		this.ordrepo.save(order);
		
	}

	@Override
	public void Update(Order order) {
		this.ordrepo.save(order);
		
	}

	@Override
	public void Delete(Order order) {
		Order  ord =this.ordrepo.getById(order.getId_Ped());
		this.ordrepo.delete(ord);
		
	}

}
