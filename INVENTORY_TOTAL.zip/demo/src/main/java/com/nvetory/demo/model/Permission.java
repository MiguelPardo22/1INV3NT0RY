package com.nvetory.demo.model;
import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "Permiso")
public class Permission implements Serializable {
	private static final long serialVersionUID = 1L;
	
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private int id_Permiso;
		
		@Column(name="NomPermiso",length=40)
		private String NomPer;
	
		@OneToMany(mappedBy = "id_Permiso_fk")
		private List<Role>ListRole;

		public int getId_Permiso() {
			return id_Permiso;
		}

		public void setId_Permiso(int id_Permiso) {
			this.id_Permiso = id_Permiso;
		}

		public String getNomPer() {
			return NomPer;
		}

		public void setNomPer(String nomPer) {
			NomPer = nomPer;
		}
		
}
