package com.nvetory.demo.model.facade;

import java.util.List;
import com.nvetory.demo.model.Role;

public interface IRol {

	public List<Role> findALL();
	public Role findById(int id_Rol);
	public void create (Role role);
	public void Update (Role role);
	public void Delete (Role role);
}
