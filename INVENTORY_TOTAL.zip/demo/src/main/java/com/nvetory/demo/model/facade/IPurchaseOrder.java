package com.nvetory.demo.model.facade;

import java.util.List;
import com.nvetory.demo.model.Purchaseorder;

public interface IPurchaseOrder {

	public List<Purchaseorder> findALL();
	public Purchaseorder findById(int id_com);
	public void create(Purchaseorder purchase_order);
	public void Update(Purchaseorder purchase_order);
	public void Delete(Purchaseorder purchase_order);
	
}