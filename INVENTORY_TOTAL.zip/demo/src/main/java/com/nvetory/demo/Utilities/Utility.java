package com.nvetory.demo.Utilities;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Utility {

	public static Date convertifecha(String Fch) {
		
		SimpleDateFormat formato = new SimpleDateFormat("yyyy/MM/dd");
		
		Date date = null;
		try {
			
			date = formato.parse(Fch);
			
		}catch (Exception e) {
			
			e.printStackTrace();
			
		}
		
		return date;
	}
	
}
