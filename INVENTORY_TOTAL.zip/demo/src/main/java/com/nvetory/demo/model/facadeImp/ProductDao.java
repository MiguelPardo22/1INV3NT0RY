package com.nvetory.demo.model.facadeImp;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nvetory.demo.model.Product;
import com.nvetory.demo.model.Repository.ProductRepository;
import com.nvetory.demo.model.facade.IProduct;

@Service
public class ProductDao implements IProduct{

	@Autowired
	private ProductRepository productrepo;
	
	@Override
	public List<Product> findALL() {
		return this.productrepo.findAll();
	}

	@Override
	public Product findById(int id_prod) {
		return this.productrepo.getReferenceById(id_prod);
	}

	@Override
	public void create(Product product) {
		this.productrepo.save(product);
		
	}

	@Override
	public void Update(Product product) {
		this.productrepo.save(product);
		
	}

	@Override
	public void Delete(Product product) {
		Product pro=this.productrepo.getById(product.getId_prod());
		this.productrepo.delete(pro);
		
	}

}

