package com.nvetory.demo.model.facadeImp;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nvetory.demo.model.State;
import com.nvetory.demo.model.Repository.StateRepository;
import com.nvetory.demo.model.facade.IState;

@Service
public class StateDao implements IState{

	@Autowired
	private StateRepository staterepo;
	
	@Override
	public List<State> findALL() {
		return this.staterepo.findAll();
	}

	@Override
	public State findById(int id_estado) {
		return this.staterepo.getReferenceById(id_estado);
	}

	@Override
	public void create(State state) {
		this.staterepo.save(state);
		
	}

	@Override
	public void Update(State state) {
		this.staterepo.save(state);
		
	}

	@Override
	public void Delete(State state) {
		State st=this.staterepo.getById(state.getId_estado());
		this.staterepo.delete(st);
		
	}

}
