package com.nvetory.demo.model.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nvetory.demo.model.State;
import com.nvetory.demo.model.Supplier;
import com.nvetory.demo.model.facadeImp.StateDao;
import com.nvetory.demo.model.facadeImp.SupplierDao;
@Controller
@RequestMapping(path = "/api/demo/Supplier")
public class SupplierController {
	

		@Autowired
		private SupplierDao supplierdao;
		
		@Autowired
		private StateDao statedao;
		
	  
		@GetMapping("/all")
	    public ResponseEntity<Map<String,Object>> allState(){
	   	 List<Supplier>ListSupplier=this.supplierdao.findALL();
	   	 Map<String,Object> respon=new HashMap<String,Object>();
	   	 respon.put("data",ListSupplier);
	   	  return new ResponseEntity<>(respon,HttpStatus.OK);
	    }	
		
		@PostMapping("/create")
	    public ResponseEntity<Map<String,Object>> createSupplier(
	   	 @RequestBody Map<String,Object> request){
	   	 Map<String,Object> respon=new HashMap();
	   	 System.out.println("@@@@"+request.toString());
	   	 
	   	 Supplier sup= new Supplier();
	   	 sup.setNit(Long.parseLong(request.get("nit").toString()));
	     sup.setNom((String) request.get("nom"));
	     sup.setTel(Long.parseLong(request.get("tel").toString()));
	     sup.setDir((String) request.get("Dir"));
	     sup.setMail((String) request.get("Mail"));
	     State st = this.statedao.findById(Integer.parseInt(request.get("id_Estado_fk").toString()));
		 sup.setId_Estado_fk(st);
		 respon.put("Message", "Se guardo exitosamente");
	   	 this.supplierdao.create(sup);
	   	 
	   	 return new ResponseEntity<>(respon,HttpStatus.OK);
	    }
		
		@PutMapping("/update/{id_Proveedor}")
	    public ResponseEntity<Map<String,Object>> UpdateSupplier(
	   		 @RequestBody Map<String,Object> request){
	   	 Map<String,Object> respon=new HashMap();
	   	 
	   	 System.out.println("@@@@"+request.toString());
			
		Supplier sup= new Supplier();
		 sup.setId_Proveedor((int) request.get("id_Proveedor"));
		 sup.setNit(Long.parseLong(request.get("nit").toString()));
	     sup.setNom((String) request.get("nom"));
	     sup.setTel(Long.parseLong(request.get("tel").toString()));
	     sup.setDir((String) request.get("Dir"));
	     sup.setMail((String) request.get("Mail"));
	     State st = this.statedao.findById(Integer.parseInt(request.get("id_Estado_fk").toString()));
		 sup.setId_Estado_fk(st);
		 respon.put("Message", "Se actualizo exitosamente");
	   	 this.supplierdao.Update(sup);
	   	 
	   	 return new ResponseEntity<>(respon,HttpStatus.OK);
	    }
		
		@GetMapping("/delete/{id_proveedor}")
	    private ResponseEntity<Map<String, Object>> deleteSupplier(@PathVariable String id_proveedor) {
	   	 Map<String,Object> respon=new HashMap<String,Object>();
	   	 Supplier sup = this.supplierdao.findById(Integer.parseInt(id_proveedor));
	   	 this.supplierdao.Delete(sup);
			 respon.put("Mensaje", "Se ha borrado");
			 List<Supplier> lista=this.supplierdao.findALL();
			 respon.put("data", lista);
			 respon.put("Status", HttpStatus.OK);
			 return new ResponseEntity<>(respon,HttpStatus.OK);
	    }
	   }   