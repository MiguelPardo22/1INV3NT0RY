package com.nvetory.demo.model.facade;

import java.util.List;
import com.nvetory.demo.model.Supplier;

public interface ISupplier {

	public List<Supplier> findALL();
	public Supplier findById(int id_Proveedor);
	public void create (Supplier supplier);
	public void Update (Supplier supplier);
	public void Delete (Supplier supplier);
	
}
