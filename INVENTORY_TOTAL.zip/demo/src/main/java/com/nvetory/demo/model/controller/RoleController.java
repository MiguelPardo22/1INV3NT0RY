package com.nvetory.demo.model.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.nvetory.demo.model.Role;
import com.nvetory.demo.model.facadeImp.RoleDao;

@Controller
@RequestMapping(path = "/api/demo/rol")
public class RoleController {
	
	@Autowired
	private RoleDao roldao;
	
     @GetMapping("/all")
     public ResponseEntity<Map<String,Object>> allRol(){
    	 List<Role>ListRoles=this.roldao.findALL();
    	 Map<String,Object> respon=new HashMap<String,Object>();
    	 respon.put("data",ListRoles);
    	  return new ResponseEntity<>(respon,HttpStatus.OK);
     }	
     
     @PostMapping("/create")
     public ResponseEntity<Map<String,Object>> createRol(
    		 @RequestBody Map<String,Object> request){
    	 Map<String,Object> respon=new HashMap();
    	 System.out.println("@@@@"+request.toString());
    	 
    	 Role ro= new Role();
    	 ro.setNom((String) request.get("nom"));
    	 respon.put("Message", "Se guardo exitosamente");
    	 this.roldao.create(ro);
    	 
    	 return new ResponseEntity<>(respon,HttpStatus.OK);
     }
     
     @PutMapping("/update/{id_Rol}")
     public ResponseEntity<Map<String,Object>> UpdateRol(@RequestBody Map<String,Object>request){
    	 Map<String,Object> respon=new HashMap<String,Object>(); 
    	 
    	 Role ro= new Role();
    	 ro.setId_Rol((Integer) request.get("id_Rol"));
    	 ro.setNom((String) request.get("nom"));
    	 respon.put("Message", "Se actualizo exitosamente");
    	 this.roldao.Update(ro);
    	 
    	 return new ResponseEntity<>(respon,HttpStatus.OK);
     }
     
     @GetMapping("/delete/{id_Rol}")
     private ResponseEntity<Map<String, Object>> deleteRol(@PathVariable String id_Rol) {
    	 Map<String,Object> respon=new HashMap<String,Object>();
    	 Role ro = this.roldao.findById(Integer.parseInt(id_Rol));
    	 this.roldao.Delete(ro);
		 respon.put("Mensaje", "Se ha borrado");
		 List<Role> lista=this.roldao.findALL();
		 respon.put("data", lista);
		 respon.put("Status", HttpStatus.OK);
		 return new ResponseEntity<>(respon,HttpStatus.OK);
     }
     
}
