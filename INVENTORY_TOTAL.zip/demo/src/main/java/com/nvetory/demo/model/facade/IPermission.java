package com.nvetory.demo.model.facade;

import java.util.List;
import com.nvetory.demo.model.Permission;

public interface IPermission{

	public List<Permission> findALL();
	public Permission findById(int id_permiso);
	public void create (Permission permission);
	public void Update (Permission permission);
	public void Delete (Permission permission);
	
}
