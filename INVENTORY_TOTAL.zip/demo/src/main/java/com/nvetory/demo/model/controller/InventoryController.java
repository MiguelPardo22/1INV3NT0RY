package com.nvetory.demo.model.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.nvetory.demo.Utilities.Utility;
import com.nvetory.demo.model.Inventory;
import com.nvetory.demo.model.User;
import com.nvetory.demo.model.facadeImp.InventoryDao;
import com.nvetory.demo.model.facadeImp.UserDao;
@Controller
@RequestMapping(path = "/api/demo/Inventory")
public class InventoryController {

	@Autowired
	private InventoryDao Inventorydao;
	
	@Autowired
	private UserDao userdao;
	
	
	@GetMapping("/all")
    public ResponseEntity<Map<String,Object>> allInventory(){
   	 List<Inventory>ListInventory=this.Inventorydao.findALL();
   	 Map<String,Object> respon=new HashMap<String,Object>();
   	 respon.put("data",ListInventory);
   	  return new ResponseEntity<>(respon,HttpStatus.OK);
    }	
	
	@PostMapping("/create")
    public ResponseEntity<Map<String,Object>> createInventory(
   		 @RequestBody Map<String,Object> request){
   	 Map<String,Object> respon=new HashMap();
   	 System.out.println("@@@@"+request.toString());
   	 
   	Inventory inv= new Inventory();
    inv.setFecha(Utility.convertifecha(request.get("Fecha").toString()));

    
	 User us = this.userdao.findById(Integer.parseInt(request.get("id_User_fk").toString()));
	 inv.setId_usu_fk(us);

   	 respon.put("Message", "Se guardo exitosamente");
   	 this.Inventorydao.create(inv);
   	 
   	 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
	
	@PutMapping("/update/{id_inventario}")
    public ResponseEntity<Map<String,Object>> UpdateInventory(
   		 @RequestBody Map<String,Object> request){
   	 Map<String,Object> respon=new HashMap();
   	 System.out.println("@@@@"+request.toString());
   	 
 	 Inventory inv= new Inventory();
 	 inv.setFecha(Utility.convertifecha(request.get("Fecha").toString()));
    
    User us = this.userdao.findById(Integer.parseInt(request.get("id_User_fk").toString()));
	 inv.setId_usu_fk(us);
	 
	 
	 respon.put("Message", "Se actualizo exitosamente");
   	 this.Inventorydao.Update(inv);
 	 
   	 return new ResponseEntity<>(respon,HttpStatus.OK);
	}
	
	@GetMapping("/delete/{id_inventario}")
    private ResponseEntity<Map<String, Object>> deleteInventory(@PathVariable String id_inventario) {
   	 Map<String,Object> respon=new HashMap<String,Object>();
   	 Inventory inv = this.Inventorydao.findById(Integer.parseInt(id_inventario));
   	 this.Inventorydao.Delete(inv);
		 respon.put("Mensaje", "Se ha borrado");
		 List<Inventory> lista=this.Inventorydao.findALL();
		 respon.put("data", lista);
		 respon.put("Status", HttpStatus.OK);
		 return new ResponseEntity<>(respon,HttpStatus.OK);
		 }
}
