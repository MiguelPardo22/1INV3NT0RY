package com.nvetory.demo.model.facadeImp;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nvetory.demo.model.Permission;
import com.nvetory.demo.model.Repository.PermissionRepository;
import com.nvetory.demo.model.facade.IPermission;

@Service
public class PermissionDao implements IPermission{

	@Autowired
	private PermissionRepository permrepo;
	
	@Override
	public List<Permission> findALL() {
		return this.permrepo.findAll();
	}

	@Override
	public Permission findById(int id_permiso) {
		return this.permrepo.getReferenceById(id_permiso);
	}

	@Override
	public void create(Permission permission) {
		this.permrepo.save(permission);
		
	}

	@Override
	public void Update (Permission permission){
		this.permrepo.save(permission);
		
	}

	@Override
	public void Delete(Permission permission) {
		Permission perm=this.permrepo.getById(permission.getId_Permiso());
		this.permrepo.delete(perm);
		
	}

}
