package com.nvetory.demo.model;

import javax.persistence.Column;
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "Detalle_Producto")
public class DetailProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_det_prod;
	
	@Column(name="Precio_compra",length=40)
	private int Pre_comp;
	
	@Column(name="Precio_venta",length=40)
	private int Pre_vent;
	
	@Column(name="Impuesto",length=40)
	private int imp;
	
	@Column(name="medida",length=40)
	private String med;
	
	@Column(name="categoria",length=40)
	private String cat;
	
	@ManyToOne
	@JoinColumn(name="id_prod_fk", referencedColumnName = "id_prod")
	private Product id_prod_fk;
	
}
