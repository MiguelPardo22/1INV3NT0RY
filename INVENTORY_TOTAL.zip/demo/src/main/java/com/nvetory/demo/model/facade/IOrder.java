package com.nvetory.demo.model.facade;

import java.util.List;
import com.nvetory.demo.model.Order;

public interface IOrder {

	public List<Order> findALL();
	public Order findById(int id_Ped);
	public void create (Order order);
	public void Update (Order order);
	public void Delete (Order order);
	
}
