package com.nvetory.demo.model.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.nvetory.demo.Utilities.Utility;
import com.nvetory.demo.model.Purchaseorder;
import com.nvetory.demo.model.State;
import com.nvetory.demo.model.Supplier;
import com.nvetory.demo.model.facadeImp.PurchaseOrderDao;
import com.nvetory.demo.model.facadeImp.StateDao;
import com.nvetory.demo.model.facadeImp.SupplierDao;


@Controller
@RequestMapping(path = "/api/demo/purchaseorder")
public class PurchaseOrderController {

	@Autowired
	private PurchaseOrderDao purchase_orderdao;
	@Autowired
	private SupplierDao supplierDao;
	@Autowired
	private StateDao stateDao;
	
	
	@GetMapping("/all")
    public ResponseEntity<Map<String,Object>> allPurchaseorder(){
   	 List<Purchaseorder>ListPurchaseorder=this.purchase_orderdao.findALL();
   	 Map<String,Object> respon=new HashMap<String,Object>();
   	 respon.put("data",ListPurchaseorder);
   	  return new ResponseEntity<>(respon,HttpStatus.OK);
    }	
	
	@PostMapping("/create")
    public ResponseEntity<Map<String,Object>> createPurchaseorder(
     @RequestBody Map<String,Object> request){
   	 Map<String,Object> respon=new HashMap();
   	 System.out.println("@@@@"+request.toString());
   	 
   	 Purchaseorder puro= new Purchaseorder();
     puro.setFecha(Utility.convertifecha(request.get("Fecha").toString()));

     Supplier sp = this.supplierDao.findById(Integer.parseInt(request.get("id_Estado_fk").toString()));
	 puro.setId_Supplier_fk(sp);
     
     State st = this.stateDao.findById(Integer.parseInt(request.get("id_Estado_fk").toString()));
	 puro.setId_Estado_fk(st);
     
   	 respon.put("Message", "Se guardo exitosamente");
   	 this.purchase_orderdao.create(puro);
   	 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
	
	@PutMapping("/update/{id_orden_compra}")
    public ResponseEntity<Map<String,Object>> updatePurchaseOrder(
   		 @RequestBody Map<String,Object> request){
   	 Map<String,Object> respon=new HashMap();
   	 System.out.println("@@@@"+request.toString());
   	 
   	Purchaseorder puro= new Purchaseorder();
   	 puro.setId_orden_compra((int) request.get("id_orden_compra"));
     puro.setFecha(Utility.convertifecha(request.get("Fecha").toString()));
     
     Supplier sp = this.supplierDao.findById(Integer.parseInt(request.get("id_Estado_fk").toString()));
	 puro.setId_Supplier_fk(sp);
     
     State st = this.stateDao.findById(Integer.parseInt(request.get("id_Estado_fk").toString()));
	 puro.setId_Estado_fk(st);
	 
   	 respon.put("Message", "Se actualizo exitosamente");
   	 this.purchase_orderdao.Update(puro);
   	 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
	
	@GetMapping("/delete/{id_orden_compra}")
    private ResponseEntity<Map<String, Object>> deletePurchaseOrder(@PathVariable String id_orden_compra) {
   	 Map<String,Object> respon=new HashMap<String,Object>();
   	 Purchaseorder puro = this.purchase_orderdao.findById(Integer.parseInt(id_orden_compra));
   	 this.purchase_orderdao.Delete(puro);
		 respon.put("Mensaje", "Se ha borrado");
		 List<Purchaseorder> lista=this.purchase_orderdao.findALL();
		 respon.put("data", lista);
		 respon.put("Status", HttpStatus.OK);
		 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
	
}