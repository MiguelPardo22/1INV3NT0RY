package com.nvetory.demo.model.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.nvetory.demo.Utilities.Utility;
import com.nvetory.demo.model.Order;
import com.nvetory.demo.model.State;
import com.nvetory.demo.model.User;
import com.nvetory.demo.model.facadeImp.OrderDao;
import com.nvetory.demo.model.facadeImp.StateDao;
import com.nvetory.demo.model.facadeImp.UserDao;
@Controller
@RequestMapping(path = "/api/demo/Order")
public class OrderController {

	@Autowired
	private OrderDao orderdao;
	@Autowired
	private UserDao userdao;
	@Autowired
	private StateDao stateDao;
	
	
	@GetMapping("/all")
    public ResponseEntity<Map<String,Object>> allState(){
   	 List<Order>ListOrder=this.orderdao.findALL();
   	 Map<String,Object> respon=new HashMap<String,Object>();
   	 respon.put("data",ListOrder);
   	  return new ResponseEntity<>(respon,HttpStatus.OK);
    }	
	
	@PostMapping("/create")
    public ResponseEntity<Map<String,Object>> createOrder(
   		 @RequestBody Map<String,Object> request){
   	 Map<String,Object> respon=new HashMap();
   	 System.out.println("@@@@"+request.toString());
   	 
   	 Order or= new Order();
   	 or.setName_cli((String) request.get("Name_cli"));
   	 or.setSub(Long.parseLong(request.get("sub").toString()));
   	 
   	 or.setFecha(Utility.convertifecha(request.get("Fecha").toString()));
   	 
   	 User us = this.userdao.findById(Integer.parseInt(request.get("id_usu_fk").toString()));
	 or.setId_usu_fk(us);
   	 
	 State st = this.stateDao.findById(Integer.parseInt(request.get("id_Estado_fk").toString()));
	 or.setId_Estado_fk(st);
	 
   	 respon.put("Message", "Se guardo exitosamente");
   	 this.orderdao.create(or);
   	 
   	 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
	
	@PutMapping("/update/{id_Ped}")
    public ResponseEntity<Map<String,Object>> UpdateOrder(
   		 @RequestBody Map<String,Object> request){
   	 Map<String,Object> respon=new HashMap();
   	 System.out.println("@@@@"+request.toString());
   	 
   	 Order or= new Order();
   	 or.setId_Ped((int) request.get("id_Ped"));
   	 or.setName_cli((String) request.get("Name_cli"));
   	 or.setSub(Long.parseLong(request.get("sub").toString()));
   	 
   	 or.setFecha(Utility.convertifecha(request.get("Fecha").toString()));
   	 
   	 User us = this.userdao.findById(Integer.parseInt(request.get("id_usu_fk").toString()));
	 or.setId_usu_fk(us);
  	 
	 State st = this.stateDao.findById(Integer.parseInt(request.get("id_Estado_fk").toString()));
	 or.setId_Estado_fk(st);
	 
   	 respon.put("Message", "Se actualizo exitosamente");
   	 this.userdao.Update(us);
   	 
   	 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
	
	@GetMapping("/delete/{id_Ped}")
    private ResponseEntity<Map<String, Object>> deleteOrder(@PathVariable String id_Ped) {
   	 Map<String,Object> respon=new HashMap<String,Object>();
   	 Order or = this.orderdao.findById(Integer.parseInt(id_Ped));
   	 this.orderdao.Delete(or);
		 respon.put("Mensaje", "Se ha borrado");
		 List<Order> lista=this.orderdao.findALL();
		 respon.put("data", lista);
		 respon.put("Status", HttpStatus.OK);
		 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
	
}