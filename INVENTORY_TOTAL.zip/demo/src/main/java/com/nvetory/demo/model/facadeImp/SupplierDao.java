package com.nvetory.demo.model.facadeImp;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nvetory.demo.model.Supplier;

import com.nvetory.demo.model.Repository.SupplierRepository;
import com.nvetory.demo.model.facade.ISupplier;

@Service
public class SupplierDao implements ISupplier{

	@Autowired
	private SupplierRepository suprepo;
	
	@Override
	public List<Supplier> findALL() {
		return this.suprepo.findAll();
	}

	@Override
	public Supplier findById(int id_Proveedor) {
		return this.suprepo.getReferenceById(id_Proveedor);
	}

	@Override
	public void create(Supplier supplier) {
		this.suprepo.save(supplier);
		
	}

	@Override
	public void Update(Supplier supplier) {
		this.suprepo.save(supplier);
		
	}

	@Override
	public void Delete(Supplier supplier) {
		Supplier sup=this.suprepo.getById(supplier.getId_Proveedor());
		this.suprepo.delete(sup);
		
	}

}
