package com.nvetory.demo.model.facadeImp;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nvetory.demo.model.Purchaseorder;
import com.nvetory.demo.model.Repository.PurchaseOrderRepository;
import com.nvetory.demo.model.facade.IPurchaseOrder;


@Service
public class PurchaseOrderDao implements IPurchaseOrder{

	@Autowired
	private PurchaseOrderRepository Purchase_orderrepo;
	
	@Override
	public List<Purchaseorder> findALL() {
		return this.Purchase_orderrepo.findAll();
	}

	@Override
	public Purchaseorder findById(int id_orden_compra) {
		return this.Purchase_orderrepo.getReferenceById(id_orden_compra);
	}

	@Override
	public void create(Purchaseorder purchaseorder) {
		this.Purchase_orderrepo.save(purchaseorder);
		
	}

	@Override
	public void Update(Purchaseorder purchaseorder) {
		this.Purchase_orderrepo.save(purchaseorder);
		
	}

	@Override
	public void Delete(Purchaseorder purchaseorder) {
		Purchaseorder puro=this.Purchase_orderrepo.getById(purchaseorder.getId_orden_compra());
		this.Purchase_orderrepo.delete(puro);
		
	}

}