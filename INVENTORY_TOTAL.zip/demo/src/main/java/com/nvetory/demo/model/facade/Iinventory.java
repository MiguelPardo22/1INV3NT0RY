package com.nvetory.demo.model.facade;

import java.util.List;
import com.nvetory.demo.model.Inventory;

public interface Iinventory {

	public List<Inventory> findALL();
	public Inventory findById(int id_inventario);
	public void create (Inventory inventory);
	public void Update (Inventory  inventory);
	public void Delete (Inventory inventory);
	
}
