package com.nvetory.demo.model.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nvetory.demo.model.Role;
import com.nvetory.demo.model.State;
import com.nvetory.demo.model.User;
import com.nvetory.demo.model.facadeImp.RoleDao;
import com.nvetory.demo.model.facadeImp.StateDao;
import com.nvetory.demo.model.facadeImp.UserDao;


@Controller
@RequestMapping(path = "/api/demo/User")
public class UserController {

	@Autowired
	private UserDao userdao;
	
	@Autowired
	private RoleDao roldao;
	
	@Autowired
	private StateDao stateDao;
	
	
	@GetMapping("/all")
    public ResponseEntity<Map<String,Object>> allUser(){
   	 List<User>ListUser=this.userdao.findALL();
   	 Map<String,Object> respon=new HashMap<String,Object>();
   	 respon.put("data",ListUser);
   	  return new ResponseEntity<>(respon,HttpStatus.OK);
    }	
	
	@PostMapping("/create")
    public ResponseEntity<Map<String,Object>> createUser(
   		 @RequestBody Map<String,Object> request){
   	 Map<String,Object> respon=new HashMap();
   	 System.out.println("@@@@"+request.toString());
   	 
   	 User us= new User();
   	 us.setNom((String) request.get("Nom"));
   	 us.setIden((int) request.get("iden"));
   	 us.setTel(Long.parseLong(request.get("Tel").toString()));
   	 us.setMail((String) request.get("Mail"));
   	 us.setCon((String) request.get("Con"));
   	
   	 Role ro = this.roldao.findById(Integer.parseInt(request.get("id_role_fk").toString()));
	 us.setId_role_fk(ro);
   	 
	 State st = this.stateDao.findById(Integer.parseInt(request.get("id_Estado_fk").toString()));
	 us.setId_Estado_fk(st);
	 
   	 respon.put("Message", "Se guardo exitosamente");
   	 this.userdao.create(us);
   	 
   	 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
	
	@PutMapping("/update/{id_usu}")
    public ResponseEntity<Map<String,Object>> UpdateUser(
   		 @RequestBody Map<String,Object> request){
   	 Map<String,Object> respon=new HashMap();
   	 
   	 System.out.println("@@@@"+request.toString());
   	 
   	 User us= new User();
   	 us.setId_usu((int) request.get("id_usu"));
   	 us.setNom((String) request.get("Nom"));
   	 us.setIden((int) request.get("iden"));
   	us.setTel(Long.parseLong(request.get("Tel").toString()));
   	 us.setMail((String) request.get("Mail"));
   	 us.setCon((String) request.get("Con"));
   	 
   	 Role ro = this.roldao.findById(Integer.parseInt(request.get("id_role_fk").toString()));
	 us.setId_role_fk(ro);
   	 
	 State st = this.stateDao.findById(Integer.parseInt(request.get("id_Estado_fk").toString()));
	 us.setId_Estado_fk(st);
	 
   	 respon.put("Message", "Se actualizo exitosamente");
   	 this.userdao.Update(us);
   	 
   	 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
	
	@GetMapping("/delete/{id_usu}")
    private ResponseEntity<Map<String, Object>> deleteUser(@PathVariable String id_usu) {
   	 Map<String,Object> respon=new HashMap<String,Object>();
   	 User us = this.userdao.findById(Integer.parseInt(id_usu));
   	 this.userdao.Delete(us);
		 respon.put("Mensaje", "Se ha borrado");
		 List<User> lista=this.userdao.findALL();
		 respon.put("data", lista);
		 respon.put("Status", HttpStatus.OK);
		 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
	
}
