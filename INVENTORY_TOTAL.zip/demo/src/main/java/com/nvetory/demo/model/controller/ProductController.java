package com.nvetory.demo.model.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.nvetory.demo.model.Product;
import com.nvetory.demo.model.State;
import com.nvetory.demo.model.facadeImp.ProductDao;
import com.nvetory.demo.model.facadeImp.StateDao;


@Controller
@RequestMapping(path = "/api/demo/product")
public class ProductController {

	@Autowired
	private ProductDao productdao;
	
	@Autowired
	private StateDao stateDao;
	
	@GetMapping("/all")
    public ResponseEntity<Map<String,Object>> allProduct(){
   	 List<Product>ListProduct=this.productdao.findALL();
   	 Map<String,Object> respon=new HashMap<String,Object>();
   	 respon.put("data",ListProduct);
   	  return new ResponseEntity<>(respon,HttpStatus.OK);
    }	
	
	@PostMapping("/create")
    public ResponseEntity<Map<String,Object>> createProduct(
   		 @RequestBody Map<String,Object> request){
   	 Map<String,Object> respon=new HashMap();
   	 System.out.println("@@@@"+request.toString());
   	 
   	 Product pro= new Product();
       	 pro.setRef(Long.parseLong(request.get("Ref").toString()));
         pro.setNom((String) request.get("nom"));
         State st = this.stateDao.findById(Integer.parseInt(request.get("id_Estado_fk").toString()));
    	 pro.setId_Estado_fk(st);
   	 respon.put("Message", "Se guardo exitosamente");
   	 this.productdao.create(pro);
   	 
   	 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
	
	@PutMapping("/update/{id_prod}")
    public ResponseEntity<Map<String,Object>> UpdateProduct(
   		 @RequestBody Map<String,Object> request){
   	 Map<String,Object> respon=new HashMap();
   	 System.out.println("@@@@"+request.toString());
   	 
   	Product pro= new Product();
   	
   	pro.setId_prod( (int) request.get("id_Prod"));
	pro.setRef(Long.parseLong(request.get("Ref").toString()));
    pro.setNom((String) request.get("nom"));
    
    State st = this.stateDao.findById(Integer.parseInt(request.get("id_Estado_fk").toString()));
	 pro.setId_Estado_fk(st);
	 
	 respon.put("Message", "Se actualizo exitosamente");
	 this.productdao.Update(pro);
	 
	 return new ResponseEntity<>(respon,HttpStatus.OK);
}
	@GetMapping("/delete/{id_prod}")
    private ResponseEntity<Map<String, Object>> deleteProduct(@PathVariable String id_prod) {
   	 Map<String,Object> respon=new HashMap<String,Object>();
   	 Product pro = this.productdao.findById(Integer.parseInt(id_prod));
   	 this.productdao.Delete(pro);
		 respon.put("Mensaje", "Se ha borrado");
		 List<Product> lista=this.productdao.findALL();
		 respon.put("data", lista);
		 respon.put("Status", HttpStatus.OK);
		 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
}