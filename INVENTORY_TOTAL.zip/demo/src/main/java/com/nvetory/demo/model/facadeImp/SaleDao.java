package com.nvetory.demo.model.facadeImp;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nvetory.demo.model.Sale;
import com.nvetory.demo.model.Repository.SaleRepository;
import com.nvetory.demo.model.facade.ISale;

@Service
public class SaleDao implements ISale{

	@Autowired
	private SaleRepository salerepo;
	
	@Override
	public List<Sale> findALL() {
		return this.salerepo.findAll();
	}

	@Override
	public Sale findById(int id_ven) {
		return this.salerepo.getReferenceById(id_ven);
	}

	@Override
	public void create(Sale  sale) {
		this.salerepo.save(sale);
		
	}

	@Override
	public void Update(Sale sale) {
		this.salerepo.save(sale);
		
	}

	@Override
	public void Delete(Sale sale) {
		Sale ven =this.salerepo.getById(sale.getId_ven());
		this.salerepo.delete(ven);
		
	}

}
