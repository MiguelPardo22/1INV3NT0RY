package com.nvetory.demo.model.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.nvetory.demo.Utilities.Utility;
import com.nvetory.demo.model.Purchase;
import com.nvetory.demo.model.State;
import com.nvetory.demo.model.Supplier;
import com.nvetory.demo.model.facadeImp.PurchaseDao;
import com.nvetory.demo.model.facadeImp.StateDao;
import com.nvetory.demo.model.facadeImp.SupplierDao;


@Controller
@RequestMapping(path = "/api/demo/purchase")
public class PurchaseController {

	@Autowired
	private PurchaseDao purchasedao;
	@Autowired
	private StateDao stateDao;
	@Autowired
	private SupplierDao supplierDao;	
	
	@GetMapping("/all")
    public ResponseEntity<Map<String,Object>> allPurchase(){
   	 List<Purchase>ListPurchase=this.purchasedao.findALL();
   	 Map<String,Object> respon=new HashMap<String,Object>();
   	 respon.put("data",ListPurchase);
   	  return new ResponseEntity<>(respon,HttpStatus.OK);
    }	
	
	@PostMapping("/create")
    public ResponseEntity<Map<String,Object>> createPurchase(
   		 @RequestBody Map<String,Object> request){
   	 Map<String,Object> respon=new HashMap();
   	 System.out.println("@@@@"+request.toString());
   	 
   	 Purchase pur= new Purchase();
     pur.setNum_fac((String) request.get("Ref"));
     pur.setTot_com((String) request.get("Tot_com"));
     pur.setFecha(Utility.convertifecha(request.get("Fecha").toString()));
     
     Supplier sp = this.supplierDao.findById(Integer.parseInt(request.get("id_Estado_fk").toString()));
	 pur.setId_Supplier_fk(sp);
     
     State st = this.stateDao.findById(Integer.parseInt(request.get("id_Estado_fk").toString()));
	 pur.setId_Estado_fk(st);
	 
   	 respon.put("Message", "Se guardo exitosamente");
   	 this.purchasedao.create(pur);
   	 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
	
	@PutMapping("/update/{id_com}")
    public ResponseEntity<Map<String,Object>> UpdatePurchase(
   		 @RequestBody Map<String,Object> request){
   	 Map<String,Object> respon=new HashMap();
   	 System.out.println("@@@@"+request.toString());
   	 
   	 Purchase pur= new Purchase();
   	 pur.setId_com((int) request.get("id_com"));
     pur.setNum_fac((String) request.get("Ref"));
     pur.setTot_com((String) request.get("Tot_com"));
     pur.setFecha(Utility.convertifecha(request.get("Fecha").toString()));
     
     Supplier sp = this.supplierDao.findById(Integer.parseInt(request.get("id_Estado_fk").toString()));
	 pur.setId_Supplier_fk(sp);
     
     State st = this.stateDao.findById(Integer.parseInt(request.get("id_Estado_fk").toString()));
	 pur.setId_Estado_fk(st);
	 
   	 respon.put("Message", "Se actualizo exitosamente");
   	 this.purchasedao.create(pur);
   	 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
	
	@GetMapping("/delete/{id_com}")
    private ResponseEntity<Map<String, Object>> deletePurchase(@PathVariable String id_com) {
   	 Map<String,Object> respon=new HashMap<String,Object>();
   	 Purchase pur = this.purchasedao.findById(Integer.parseInt(id_com));
   	 this.purchasedao.Delete(pur);
		 respon.put("Mensaje", "Se ha borrado");
		 List<Purchase> lista=this.purchasedao.findALL();
		 respon.put("data", lista);
		 respon.put("Status", HttpStatus.OK);
		 return new ResponseEntity<>(respon,HttpStatus.OK);
    }
	
}

