
package com.nvetory.demo.model.facade;

import java.util.List;
import com.nvetory.demo.model.State;

public interface IState {

	public List<State> findALL();
	public State findById(int id_estado);
	public void create (State state);
	public void Update (State state);
	public void Delete (State state);
	
}