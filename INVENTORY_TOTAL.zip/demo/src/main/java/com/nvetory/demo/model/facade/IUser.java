package com.nvetory.demo.model.facade;

import java.util.List;
import com.nvetory.demo.model.User;

public interface IUser {

	public List<User> findALL();
	public User findById(int id_usu);
	public void create (User user);
	public void Update (User user);
	public void Delete (User user);
	
}
