package com.nvetory.demo.model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "Estado")
public class State implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_estado;
	
	@Column(name="NomEstado",length=40)
	private String NomEstado;
	
	@OneToMany(mappedBy = "id_Estado_fk")
	private List<Order>ListOrder;
	
	@OneToMany(mappedBy = "id_Estado_fk")
	private List<Purchase>ListPurchase;
	
	@OneToMany(mappedBy = "id_Estado_fk")
	private List<Product>ListProduct;
	
	@OneToMany(mappedBy = "id_Estado_fk")
	private List<Supplier>ListSupplier;
	
	@OneToMany(mappedBy = "id_Estado_fk")
	private List<User>ListUser;
	
	@OneToMany(mappedBy = "id_Estado_fk")
	private List<Purchaseorder>ListPurchaseOrder;

	public int getId_estado() {
		return id_estado;
	}

	public void setId_estado(int id_estado) {
		this.id_estado = id_estado;
	}

	public String getNomEstado() {
		return NomEstado;
	}

	public void setNomEstado(String nomEstado) {
		NomEstado = nomEstado;
	}
}
