package com.app.web.Controller;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.app.web.facadeimp.RoleDao;
import com.app.web.model.Role;

@Controller
public class RoleController {
	
	@Autowired
	public RoleDao roledao;
	
	@RequestMapping({"/RoleWEB", "/"})
	public String ListRol(Model modelo){
		modelo.addAttribute("Role", roledao.Encontrarrole());
		return "RoleWEB";
	}
	
	@RequestMapping({"/getOne"})
	@ResponseBody
	public Optional<Role> getOne(Integer id_Rol){
		return roledao.getOne(id_Rol);
	}
	
	@PostMapping({"/Rolecrear"})
	public String create(Role role){
		roledao.create(role);
		return "redirect:/RoleWEB"; 
	}
	
	@RequestMapping(value="/Roleupdate", method= {RequestMethod.PUT, RequestMethod.GET})
	public String update(Role role){
		roledao.Update(role);
		return "redirect:/RoleWEB"; 
	}
	 
	//@RequestMapping(value="/RoleDelete", method ={RequestMethod.PUT, RequestMethod.GET})
	@GetMapping("/RoleDelete")
	public String delete(@PathVariable("id_Rol") Integer id_Rol) {
		
		Role ro = roledao.findById(id_Rol);
		ro.setEst("Inactivo");
		
        this.roledao.Delete(ro);
		return "redirect:/RoleWEB"; 
	}
	
	
}
