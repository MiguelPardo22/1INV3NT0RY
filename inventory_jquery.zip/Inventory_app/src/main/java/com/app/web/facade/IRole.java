package com.app.web.facade;

import java.util.List;
import java.util.Optional;

import com.app.web.model.Role;


public interface IRole {

	public List<Role>Encontrarrole();
	public Optional<Role> getOne(Integer id_Rol);
	public Role findById(Integer id_Rol);
	public void create (Role role);
	public void Update (Role role);
	public void Delete(Role role);
}
