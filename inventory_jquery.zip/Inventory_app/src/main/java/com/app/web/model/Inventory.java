package com.app.web.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.*;

@Entity
@Table(name = "Inventario")
public class Inventory implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_inventario;
	
	@Temporal(TemporalType.DATE)
    private Date Fecha;
	
	@ManyToOne
	@JoinColumn(name="id_usu_fk", referencedColumnName = "id_usu")
	private User id_usu_fk;
	
	@OneToMany(mappedBy = "id_inventario_fk")
	private List<InventoryDetail>ListInventoryDetail;

	public int getId_inventario() {
		return id_inventario;
	}

	public void setId_inventario(int id_inventario) {
		this.id_inventario = id_inventario;
	}

	public Date getFecha() {
		return Fecha;
	}

	public void setFecha(Date fecha) {
		Fecha = fecha;
	}

	public User getId_usu_fk() {
		return id_usu_fk;
	}

	public void setId_usu_fk(User id_usu_fk) {
		this.id_usu_fk = id_usu_fk;
	}
}
