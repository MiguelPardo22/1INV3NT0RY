package com.app.web.model;
import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Usuario")
public class User implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_usu;
	
	@Column(name="Identificacion",length=40)
	private int iden;
	
	@Column(name="Nombre",length=40)
	private String Nom;
	
	@Column(name="Telefono",length=40)
	private long Tel;
	
	@Column(name="Mail",length=40)
	private String Mail;
	
	@Column(name="Contraseña",length=40)
	private String Con;
	
	@ManyToOne
	@JoinColumn(name="id_role_fk", referencedColumnName = "id_Rol")
	private Role id_role_fk;  
	
	@ManyToOne
	@JoinColumn(name="id_Estado_fk", referencedColumnName = "id_estado")
	private State id_Estado_fk;
	
	@OneToMany(mappedBy = "id_usu_fk")
	private List<Order>ListOrder;
	
	@OneToMany(mappedBy = "id_usu_fk")
	private List<Inventory>ListInventory;

	public int getId_usu() {
		return id_usu;
	}

	public void setId_usu(int id_usu) {
		this.id_usu = id_usu;
	}

	public String getNom() {
		return Nom;
	}

	public void setNom(String nom) {
		Nom = nom;
	}

	public Long getTel() {
		return Tel;
	}

	public void setTel(Long tel) {
		Tel = tel;
	}

	public String getMail() {
		return Mail;
	}

	public void setMail(String mail) {
		Mail = mail;
	}

	public String getCon() {
		return Con;
	}

	public void setCon(String con) {
		Con = con;
	}

	public Role getId_role_fk() {
		return id_role_fk;
	}

	public void setId_role_fk(Role id_role_fk) {
		this.id_role_fk = id_role_fk;
	}

	public State getId_Estado_fk() {
		return id_Estado_fk;
	}

	public void setId_Estado_fk(State id_Estado_fk) {
		this.id_Estado_fk = id_Estado_fk;
	}

	public long getIden() {
		return iden;
	}

	public void setIden(int iden) {
		this.iden = iden;
	}
	
}
