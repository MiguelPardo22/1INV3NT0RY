package com.app.web.model;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "Pedido")
public class Order implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_Ped;
	
	@Column(name="Nombre_Cliente",length=40)
	private String Name_cli;

	@Column(name="Subtotal",length=40)
	private long sub;
	
	@Temporal(TemporalType.DATE)
    private Date Fecha;
	
	@ManyToOne
	@JoinColumn(name="id_usu_fk", referencedColumnName = "id_usu")
	private User id_usu_fk; 
	
	@ManyToOne
	@JoinColumn(name="id_Estado_fk", referencedColumnName = "id_estado")
	private State id_Estado_fk;
	
	@OneToMany(mappedBy = "id_ped_fk")
	private List<Orderdetail>Listorderdetail;
	
	@OneToMany(mappedBy = "id_ped_fk")
	private List<Sale>Listsale;
	
	public int getId_Ped() {
		return id_Ped;
	}

	public void setId_Ped(int id_Ped) {
		this.id_Ped = id_Ped;
	}

	public String getName_cli() {
		return Name_cli;
	}

	public void setName_cli(String name_cli) {
		Name_cli = name_cli;
	}

	public long getSub() {
		return sub;
	}

	public void setSub(long sub) {
		this.sub = sub;
	}

	public Date getFecha() {
		return Fecha;
	}

	public void setFecha(Date fecha) {
		Fecha = fecha;
	}

	public User getId_usu_fk() {
		return id_usu_fk;
	}

	public void setId_usu_fk(User id_usu_fk) {
		this.id_usu_fk = id_usu_fk;
	}

	public State getId_Estado_fk() {
		return id_Estado_fk;
	}

	public void setId_Estado_fk(State id_Estado_fk) {
		this.id_Estado_fk = id_Estado_fk;
	}
}

