package com.app.web.facadeimp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.app.web.Repository.RoleRepository;
import com.app.web.facade.IRole;
import com.app.web.model.Role;

@Service
public class RoleDao implements IRole{

	@Autowired
	private RoleRepository rolerepo;
	
	@Override
	public List<Role>Encontrarrole(){
		return rolerepo.findAll();
	}

	@Override
	public Optional<Role> getOne(Integer id_Rol) {
		return rolerepo.findById(id_Rol);
	}

	@Override
	public void create(Role role) {
		this.rolerepo.save(role);
	}

	@Override
	public void Update(Role role) {
		this.rolerepo.save(role);
		
	}

	@Override
	public void Delete(Role role) {
		Role ro=this.rolerepo.getById(role.getId_Rol());
		this.rolerepo.delete(ro);
	}


}
