package com.nvetory.demo.model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


	@Entity
	@Table(name = "Medida")
	public class Measure  implements Serializable {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private int id;

		@Column(name="Unidaddemedida",length=40)
		private String Unit;
		
		@OneToMany(mappedBy = "id_medida_fk")
		private List<Product>ListProduct;
		
		@OneToMany(mappedBy = "id_det_ped_fk")
		private List<orderdetail>Listorderdetail;
		

}
