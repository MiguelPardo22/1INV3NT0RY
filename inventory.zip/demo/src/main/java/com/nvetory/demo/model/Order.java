package com.nvetory.demo.model;
import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "Pedido")
public class Order implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_Ped;
	
	@Column(name="Nombre_Cliente",length=40)
	private String Name_cli;
	
	@Column(name="Subtotal",length=40)
	private long sub;
	
	@Column(name="Fecha",length=40)
	private String date;
	
	@ManyToOne
	@JoinColumn(name="id_usu_fk", referencedColumnName = "id_usu")
	private User id_usu_fk; 
	
	@OneToMany(mappedBy = "id_det_ped_fk")
	private List<orderdetail>Listorderdetail;
	
	@OneToMany(mappedBy = "id_sale_fk")
	private List<sale>Listsale;
}

