package com.nvetory.demo.model;
import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name = "Producto")
public class Product  implements Serializable {
	/*
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_prod;

	@Column(name="Referencia",length=40)
	private long Ref;
	
	@Column(name="Nombre",length=40)
	private String nom;
	
	@Column(name="Precio_compra",length=40)
	private int Pre_comp;
	
	@Column(name="Precio_venta",length=40)
	private int Pre_vent;
	
	@Column(name="Impuesto",length=40)
	private int imp;
	
	@ManyToOne
	@JoinColumn(name="id_category_fk", referencedColumnName = "id_cate")
	private Category id_category_fk;
	
	@ManyToOne
	@JoinColumn(name="id_medida_fk", referencedColumnName = "id")
	private Measure id_medida_fk;
	
	@OneToMany(mappedBy = "id_det_ped_fk")
	private List<orderdetail>Listorderdetail;
}
			