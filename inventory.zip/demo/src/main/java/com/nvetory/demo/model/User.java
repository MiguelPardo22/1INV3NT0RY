package com.nvetory.demo.model;
import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Usuarios")

public class User implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_usu;
	
	@Column(name="Nombre",length=40)
	private String Nom;
	
	@Column(name="Telefono",length=40)
	private String Tel;
	
	@Column(name="Mail",length=40)
	private String Mail;
	
	@Column(name="Contraseña",length=40)
	private String Con;
	
	@ManyToOne
	@JoinColumn(name="id_role_fk", referencedColumnName = "id_Rol")
	private role id_role_fk;  
	
	@OneToMany(mappedBy = "id_usu_fk")
	private List<Order>ListOrder;
	
}
