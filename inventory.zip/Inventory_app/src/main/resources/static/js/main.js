/**
 * 
 */
 
 $('document').ready(function() {
	 
	 $('.table .btn').on('click', function(event){
		 
		 event.preventDefault();
		  
		/*var href= $(this).attr('href');
		 
		 $.get(href, function(role, status){
			 
			 $('#idRolEdit').val(role.id_Rol);
			 $('#nomEdit').val(role.nom);
			 
		 });*/
		 
		 $('#editModal').modal();
		 
	 });
	 
 });
 