package com.app.web.servicio;

import java.util.List;

import com.app.web.model.Role;

public interface RoleServicio {

	public List<Role>ListarRole();
	
}
