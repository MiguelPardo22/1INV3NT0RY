package com.app.web.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.app.web.Repository.RoleRepository;
import com.app.web.model.Role;

@Service
public class RoleImp implements RoleServicio{

	@Autowired
	private RoleRepository rolerepo;
	
	@Override
	public List<Role>Encontrarrole(){
		return rolerepo.findAll();
	}


}
