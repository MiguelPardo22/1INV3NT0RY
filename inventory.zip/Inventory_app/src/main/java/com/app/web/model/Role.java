package com.app.web.model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Roles")
public class Role implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_Rol;

	@Column(name="nombre",length=40)
	private String nom;
	
	@ManyToOne
	@JoinColumn(name="id_Permiso_fk", referencedColumnName = "id_Permiso")
	private Permission id_Permiso_fk; 
	
	@OneToMany(mappedBy = "id_role_fk")
	private List<User>ListUser;

	public int getId_Rol() {
		return id_Rol;
	}

	public void setId_Rol(int id_Rol) {
		this.id_Rol = id_Rol;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	@Override
	public String toString() {
		return "Role [id_Rol=" + id_Rol + ", nom=" + nom + ", id_Permiso_fk=" + id_Permiso_fk + ", ListUser=" + ListUser
				+ "]";
	}
	
}
