package com.app.web.model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Provedor")
public class Supplier  implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_Proveedor;

	@Column(name="nit",length=40)
	private long nit;
	
	@Column(name="nombre",length=40)
	private String nom;
	
	
	@Column(name="telefono",length=40)
	private long tel;
	
	@Column(name="Direccion",length=40)
	private String Dir;
	
	@Column(name="Mail",length=40)
	private String Mail;
	
	@ManyToOne
	@JoinColumn(name="id_Estado_fk", referencedColumnName = "id_estado")
	private State id_Estado_fk;
	
	@OneToMany(mappedBy = "id_Supplier_fk")
	private List<Purchase>ListPurchase;
	
	@OneToMany(mappedBy = "id_Supplier_fk")
	private List<InventoryDetail>ListInventoryDetail;
	
	@OneToMany(mappedBy = "id_Supplier_fk")
	private List<Purchaseorder>ListPurchaseOrder;

	public int getId_Proveedor() {
		return id_Proveedor;
	}

	public void setId_Proveedor(int id_Proveedor) {
		this.id_Proveedor = id_Proveedor;
	}

	public long getNit() {
		return nit;
	}

	public void setNit(long nit) {
		this.nit = nit;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public long getTel() {
		return tel;
	}

	public void setTel(long tel) {
		this.tel = tel;
	}

	public String getDir() {
		return Dir;
	}

	public void setDir(String dir) {
		Dir = dir;
	}

	public String getMail() {
		return Mail;
	}

	public void setMail(String mail) {
		Mail = mail;
	}

	public State getId_Estado_fk() {
		return id_Estado_fk;
	}

	public void setId_Estado_fk(State id_Estado_fk) {
		this.id_Estado_fk = id_Estado_fk;
	}
	
	
	

}
