package com.app.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.app.web.Repository.RoleRepository;
import com.app.web.model.Role;

@SpringBootApplication
public class InventoryAppApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(InventoryAppApplication.class, args);
	}

	@Autowired
	private RoleRepository rolrepo;
	
	@Override
	public void run(String... args) throws Exception {
		/*Role rol = new Role("Administador", null);
		rolrepo.save(rol);
		
		Role rol1 = new Role("Bodeguero", null);
		rolrepo.save(rol1);*/
	}

}
