package com.app.web.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Detalle_Compra")
public class DetailPurchase implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_det_com;
	
	@Column(name="Cantidad",length=40)
	private int Can;
	
	@Column(name="Numero_Factura",length=40)
	private Long NumFac;
	
	@ManyToOne
	@JoinColumn(name = "id_prod_fk", referencedColumnName = "id_prod")
	private Product id_prod_fk; 
	
	@ManyToOne
	@JoinColumn(name="id_Purchase_fk", referencedColumnName = "id_com")
	private Purchase id_Purchase_fk;

	public DetailPurchase(int id_det_com, int can, Long numFac, Product id_prod_fk, Purchase id_Purchase_fk) {
		super();
		this.id_det_com = id_det_com;
		Can = can;
		NumFac = numFac;
		this.id_prod_fk = id_prod_fk;
		this.id_Purchase_fk = id_Purchase_fk;
	}

	public int getId_det_com() {
		return id_det_com;
	}

	public void setId_det_com(int id_det_com) {
		this.id_det_com = id_det_com;
	}

	public int getCan() {
		return Can;
	}

	public void setCan(int can) {
		Can = can;
	}

	public Long getNumFac() {
		return NumFac;
	}

	public void setNumFac(Long numFac) {
		NumFac = numFac;
	}

	public Product getId_prod_fk() {
		return id_prod_fk;
	}

	public void setId_prod_fk(Product id_prod_fk) {
		this.id_prod_fk = id_prod_fk;
	}

	public Purchase getId_Purchase_fk() {
		return id_Purchase_fk;
	}

	public void setId_Purchase_fk(Purchase id_Purchase_fk) {
		this.id_Purchase_fk = id_Purchase_fk;
	} 
	
	
	
}
